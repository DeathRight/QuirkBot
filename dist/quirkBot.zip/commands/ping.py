def run(*args):
    return "pong"
