def run(*args):
    args[0].importCommands()
    return "Refreshed"
